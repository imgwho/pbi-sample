# Power BI 零售分析看板结构分析

## 📊 概述

这是一个基于 Power BI 的零售分析看板（Retail Analysis Sample），用于分析和比较零售业务的年度销售表现。看板采用星型模型设计，包含完整的数据模型、DAX 度量值和交互式可视化组件。

---

## 🗂️ 数据模型架构

### 数据模型设计

基于**星型模型（Star Schema）**设计，包含1个事实表和4个主要维度表。

### 1️⃣ 事实表（Fact Table）

#### **Sales** - 销售事实表
- **状态**: 隐藏表（用户不直接查看原始数据）
- **用途**: 存储月度销售交易数据
- **关键字段**:
  - `MonthID` - 月份标识
  - `ItemID` - 商品ID
  - `LocationID` - 门店位置ID
  - `Sum_GrossMarginAmount` - 毛利润金额
  - `Sum_Regular_Sales_Dollars` - 常规销售额
  - `Sum_Markdown_Sales_Dollars` - 折扣销售额
  - `Sum_Regular_Sales_Units` - 常规销售数量
  - `Sum_Markdown_Sales_Units` - 折扣销售数量
  - `ScenarioID` - 场景标识（1=今年, 2=去年）
  - `ReportingPeriodID` - 报告期间ID（计算列）

- **数据源**: SQL Server - `RetailBIDW.dbo.Monthly_sales`
- **采样**: 10% 数据采样

### 2️⃣ 维度表（Dimension Tables）

#### **District** - 区域维度表
- **用途**: 存储销售区域和区域经理信息
- **关键字段**:
  - `DistrictID` - 区域ID
  - `District` - 区域名称
  - `DM` - 区域经理姓名（主键）
  - `DM_Pic` - 区域经理照片URL
  - `DMImage` - 区域经理照片（二进制）
  - `BusinessUnitID` - 业务单元ID

- **数据源**: SQL Server - `RetailBIDW.dbo.District_Dimension`

#### **Store** - 门店维度表
- **用途**: 存储门店详细信息
- **关键字段**:
  - `LocationID` - 位置ID（主键，隐藏）
  - `StoreNumberName` - 门店编号名称（默认标签）
  - `StoreNumber` - 门店编号
  - `Name` - 门店名称
  - `City Name` - 城市名（隐藏）
  - `Territory` - 州/省
  - `PostalCode` - 邮政编码
  - `OpenDate` - 开业日期
  - `SellingAreaSize` - 销售面积
  - `Chain` - 连锁店名称
  - `DM` - 区域经理
  - `DistrictID` - 区域ID

- **计算列**:
  - `City` = [City Name] & ", " & [Territory]
  - `Open Year` = YEAR([OpenDate])
  - `Store Type` = IF([Open Year]=2014, "New Store", "Same Store")
  - `Open Month` = FORMAT([OpenDate], "MMM")
  - `Open Month No` = MONTH([OpenDate])

- **数据源**: SQL Server - `RetailBIDW.ip.retail.StoreDim`

#### **Item** - 商品维度表
- **用途**: 存储商品分类信息
- **关键字段**:
  - `ItemID` - 商品ID（隐藏）
  - `Segment` - 细分市场
  - `Category` - 类别
  - `Buyer` - 采购员
  - `FamilyNane` - 商品系列

- **数据源**: SQL Server - `RetailBIDW.dbo.Item_Dimension`

#### **Time** - 时间维度表
- **用途**: 提供时间层级分析
- **数据类别**: Time
- **关键字段**:
  - `ReportingPeriodID` - 报告期间ID（隐藏）
  - `Period` - 期间（月份数字）
  - `FiscalYear` - 财务年度
  - `FiscalMonth` - 财务月份（文本，如 "Jan", "Feb"）
  - `Month` - 月份日期（主键）

- **数据源**: SQL Server - `RetailBIDW.Time_Dimension`
- **注释**: 启用了 Power BI 时间智能功能

### 3️⃣ 表关系（Relationships）

```
数据模型关系图:

District (DistrictID) ←→ Store (DistrictID)
                              ↓
                        Store (LocationID) ←→ Sales (LocationID)
                                                  ↓
                                            Sales (ItemID) ←→ Item (ItemID)
                                                  ↓
                                            Sales (ReportingPeriodID) ←→ Time (ReportingPeriodID)
```

**关系详情**:
1. `Store.DistrictID` → `District.DistrictID`
2. `Sales.LocationID` → `Store.LocationID`
3. `Sales.ItemID` → `Item.ItemID`
4. `Sales.ReportingPeriodID` → `Time.ReportingPeriodID`
5. `Store.OpenDate` → `LocalDateTable` (日期层级)
6. `Time.Month` → `LocalDateTable` (日期层级)

---

## 📈 可视化组件

### 看板页面: "District Monthly Sales"

该页面包含 **7个可视化元素**：

#### 1. **VisualContainer** - 页面标题
- **类型**: 文本框 (textbox)
- **内容**: "District Monthly Sales"
- **样式**: Segoe UI Light, 28pt
- **位置**: 页面顶部居中

#### 2. **VisualContainer1** - 月度销售变化柱状图
- **类型**: 聚类柱状图 (clusteredColumnChart)
- **位置**: 右上角
- **尺寸**: 275px × 273px
- **数据绑定**:
  - X轴 (Category): `Time.FiscalMonth` (财务月份)
  - Y轴: `Sales.Total Sales Variance %` (销售变化百分比)
- **配置**:
  - 轴类型: 分类轴
  - 数据标签: 隐藏
  - 图例: 显示在底部

#### 3. **VisualContainer2** - 版权信息
- **类型**: 文本框 (textbox)
- **内容**: "obviEnce llc ©"
- **样式**: Heading, 8pt
- **对齐**: 右对齐
- **位置**: 页面右下角

#### 4. **VisualContainer3** - 去年 vs 今年销售对比面积图
- **类型**: 面积图 (areaChart)
- **位置**: 左下方
- **尺寸**: 426.67px × 279.82px
- **数据绑定**:
  - X轴 (Category): `Time.FiscalMonth`
  - Y轴 (双系列):
    - `Sales.Last Year Sales` (去年销售额)
    - `Sales.This Year Sales` (今年销售额)
- **排序**: 按 FiscalMonth 升序

#### 5. **VisualContainer4** - 气泡图（按类别的销售方差分析）
- **类型**: 散点图 (scatterChart)
- **位置**: 右下方
- **尺寸**: 509.85px × 279.82px
- **数据绑定**:
  - X轴: `Sales.Total Sales Variance %` (销售变化百分比)
  - Y轴: `Sales.Avg $/Unit TY` (今年平均单价)
  - 气泡大小: `Sales.This Year Sales` (今年销售额)
  - 类别/系列: `Item.Category` (商品类别)
- **排序**: 按 Total Sales Variance % 降序
- **配置**: 显示类别标签

#### 6. **VisualContainer5** - 门店月度销售柱状图
- **类型**: 聚类柱状图 (clusteredColumnChart)
- **位置**: 页面中上部
- **尺寸**: 535.29px × 260.45px
- **数据绑定**:
  - X轴 (Category): `Store.StoreNumberName` (门店编号名称)
  - Y轴: `Sales.This Year Sales` (今年销售额)
- **排序**: 按 StoreNumber 降序
- **配置**: 显示数据标签

#### 7. **VisualContainer6** - 区域经理筛选器
- **类型**: 切片器 (slicer)
- **位置**: 左上角
- **尺寸**: 116.45px × 241.08px
- **数据源**: `District.DM` (区域经理)
- **标题**: "District Manager"
- **配置**:
  - 标题显示: 是
  - 标题颜色: 黑色
  - 切片器标题: 隐藏

---

## 🔢 核心 DAX 度量值

Sales 表中定义了 **30+ 个度量值**，以下是主要度量值：

### 销售额度量值

```dax
// 基础销售额
Regular_Sales_Dollars = SUM([Sum_Regular_Sales_Dollars])
Markdown_Sales_Dollars = SUM([Sum_Markdown_Sales_Dollars])
TotalSales = [Regular_Sales_Dollars] + [Markdown_Sales_Dollars]

// 今年销售额
TotalSalesTY = CALCULATE([TotalSales], Sales[ScenarioID]=1)

// 去年销售额
TotalSalesLY = CALCULATE([TotalSales], Sales[ScenarioID]=2)
Last Year Sales = [TotalSalesLY]

// 今年销售额（别名）
This Year Sales = [TotalSalesTY]

// 销售额差异
Total Sales Var = [TotalSalesTY] - [TotalSalesLY]
Total Sales Variance = [Total Sales Var]

// 销售额差异百分比
Total Sales Var % = IF([TotalSalesLY]<>0, [Total Sales Var]/[TotalSalesLY], BLANK())
Total Sales Variance % = [Total Sales Var %]
```

### 毛利润度量值

```dax
// 今年毛利润
Gross Margin This Year = CALCULATE(SUM([Sum_GrossMarginAmount]), Sales[ScenarioID]=1)

// 今年毛利率
Gross Margin This Year % = [Gross Margin This Year]/[TotalSalesTY]

// 去年毛利润
Gross Margin Last Year = CALCULATE(SUM([Sum_GrossMarginAmount]), Sales[ScenarioID]=2)

// 去年毛利率
Gross Margin Last Year % = [Gross Margin Last Year]/[TotalSalesLY]
```

### 单位销量度量值

```dax
// 基础销量
Regular_Sales_Units = SUM([Sum_Regular_Sales_Units])
Markdown_Sales_Units = SUM([Sum_Markdown_Sales_Units])
TotalUnits = [Regular_Sales_Units] + [Markdown_Sales_Units]

// 今年销量
Total Units This Year = CALCULATE([TotalUnits], Sales[ScenarioID]=1)

// 去年销量
Total Units Last Year = CALCULATE([TotalUnits], Sales[ScenarioID]=2)

// 今年平均单价
Avg $/Unit TY = IF([Total Units This Year]<>0, [TotalSalesTY]/[Total Units This Year], BLANK())
Average Unit Price = [Avg $/Unit TY]

// 去年平均单价
Avg $/Unit LY = IF([Total Units Last Year]<>0, [TotalSalesLY]/[Total Units Last Year], BLANK())
Average Unit Price Last Year = [Avg $/Unit LY]
```

### 其他业务度量值

```dax
// 每平方英尺销售额（年化）
Sales Per Sq Ft = ([TotalSalesTY]/(DISTINCTCOUNT([MonthID])*SUM(Store[SellingAreaSize])))*12

// 门店数量
Store Count = DISTINCTCOUNT([LocationID])
```

### Store 表度量值

```dax
// 平均销售面积
Average Selling Area Size = AVERAGE([SellingAreaSize])

// 新店数量
New Stores = CALCULATE(COUNTA([Store Type]), FILTER(ALL(Store), [Store Type]="New Store"))

// 新店目标
New Stores Target = 14

// 门店总数
Total Stores = COUNTA([StoreNumberName])

// 开业门店数
Open Store Count = COUNTA([OpenDate])
```

### KPI 指标

两个主要销售度量值配置了 KPI（关键绩效指标）：

**TotalSalesTY KPI**:
- 目标: `TotalSalesLY` (去年销售额)
- 状态图形: 交通灯 - 单灯
- 状态表达式:
  - 红灯 (差): < 95% 目标
  - 黄灯 (一般): 95% - 100% 目标
  - 绿灯 (好): > 100% 目标

**This Year Sales KPI**:
- 目标: `Last Year Sales`
- 状态图形: 交通灯 - 单灯
- 状态表达式: 同上

---

## 🎯 筛选器配置

页面级别配置了 **6个筛选器**，允许用户进行多维度数据分析：

1. **Time.FiscalMonth** - 财务月份筛选
   - 类型: 分类筛选器
   - 用途: 按月份筛选数据

2. **District.District** - 区域筛选
   - 类型: 分类筛选器
   - 用途: 按销售区域筛选

3. **District.DM** - 区域经理筛选
   - 类型: 分类筛选器
   - 用途: 按区域经理筛选

4. **Store.Name** - 门店名称筛选
   - 类型: 分类筛选器
   - 用途: 按门店筛选

5. **Store.Chain** - 连锁店筛选
   - 类型: 分类筛选器
   - 用途: 按连锁品牌筛选

6. **Item.Category** - 商品类别筛选
   - 类型: 分类筛选器
   - 用途: 按商品类别筛选

---

## 💾 数据源与 ETL

### 数据源

所有表都从 **SQL Server 数据库** `RetailBIDW` 加载数据。

### Power Query 转换（M 语言）

每个表的加载过程包含以下标准步骤：

1. **Source** - 连接到 SQL Server 并执行查询
2. **Renamed Columns** - 重命名列以符合业务术语
3. **Changed Type** - 转换数据类型

#### Sales 表加载示例

```m
let
    Source = Sql.Database(".", "RetailBIDW", [Query="SELECT s.[MonthID]+200 MonthID
      ,s.[ItemID]
      ,s.[LocationID]
      ,s.[Sum_GrossMarginAmount]
      ,s.[Sum_Regular_Sales_Dollars]
      ,s.[Sum_Markdown_Sales_Dollars]
      ,s.[Sum_Regular_Sales_Units]
      ,s.[Sum_Markdown_Sales_Units]
      ,s.[ScenarioID]
  FROM [dbo].[Monthly_sales] s tablesample (10 percent), IP.[Retail].[StoreDim] d
  where s.LocationID = d.[LocationID]
 and MonthID+200>=concat(year(d.opendate ),RIGHT('0'+cast(month(d.opendate ) as varchar(2)), 2) )"]),
    #"Renamed Columns" = Table.RenameColumns(Source, {...}),
    #"Changed Type" = Table.TransformColumnTypes(#"Renamed Columns", {...})
in
    #"Changed Type"
```

**特点**:
- 使用 `TABLESAMPLE (10 percent)` 进行数据采样
- MonthID 加 200 进行日期调整
- 与 StoreDim 表关联过滤

#### Time 表加载示例

```m
let
    Source = Sql.Database(".", "RetailBIDW", [Query="select distinct
concat(year(dateadd(year, 2, [BusinessDayDate] )),RIGHT('0'+cast(month(dateadd(year, 2, [BusinessDayDate] )) as varchar(2)), 2), RIGHT('0'+cast(day(dateadd(year, 2, [BusinessDayDate] )) as varchar(2)), 2) ) ReportingPeriodID,
  month(dateadd(year, 2, [BusinessDayDate] )) Period,
  left(DATENAME(month, dateadd(year, 2, [BusinessDayDate] )), 3) FiscalMonth,
  year(dateadd(year, 2, [BusinessDayDate] ) ) FiscalYear,
  dateadd(year, 2, [BusinessDayDate] ) [BusinessDayDate]
from [Time_Dimension]"]),
    #"Renamed Columns" = Table.RenameColumns(Source, {...}),
    #"Changed Type" = Table.TransformColumnTypes(#"Renamed Columns", {...})
in
    #"Changed Type"
```

**特点**:
- 使用 `DATEADD(year, 2, ...)` 将日期向前推移2年
- 格式化月份名称为3字母缩写（Jan, Feb等）

---

## 🎨 主题与样式

### 主题
- **名称**: Concourse
- **类型**: RegisteredResources (注册资源主题)
- **版本信息**:
  - Visual: 1.8.26
  - Report: 2.0.26
  - Page: 1.3.26

### 项目设置
- **自动恢复**: 已启用 (enableAutoRecovery: true)
- **Power BI 数据源版本**: powerBI_V3
- **源查询区域设置**: en-US
- **模型区域设置**: en-US (English - United States)
- **时间智能**: 已启用

---

## 📂 文件结构

```
Retail Analysis Sample PBIX (1).pbip
│
├── Retail Analysis Sample PBIX (1).Report/
│   ├── .pbi/
│   │   └── localSettings.json
│   └── definition/
│       ├── report.json
│       ├── version.json
│       └── pages/
│           ├── pages.json
│           └── ReportSection2/
│               ├── page.json
│               └── visuals/
│                   ├── VisualContainer/visual.json
│                   ├── VisualContainer1/visual.json
│                   ├── VisualContainer2/visual.json
│                   ├── VisualContainer3/visual.json
│                   ├── VisualContainer4/visual.json
│                   ├── VisualContainer5/visual.json
│                   └── VisualContainer6/visual.json
│
└── Retail Analysis Sample PBIX (1).SemanticModel/
    ├── .pbi/
    │   ├── editorSettings.json
    │   └── localSettings.json
    ├── definition/
    │   ├── database.tmdl
    │   ├── model.tmdl
    │   ├── relationships.tmdl
    │   ├── cultures/
    │   │   └── en-US.tmdl
    │   └── tables/
    │       ├── DateTableTemplate_*.tmdl
    │       ├── District.tmdl
    │       ├── Item.tmdl
    │       ├── LocalDateTable_*.tmdl
    │       ├── Sales.tmdl
    │       ├── Store.tmdl
    │       └── Time.tmdl
    └── diagramLayout.json
```

---

## 🎯 业务应用场景

这个 Power BI 看板适用于以下业务场景：

1. **销售绩效监控**
   - 实时对比今年与去年的销售表现
   - 识别销售趋势和季节性模式

2. **区域管理**
   - 按区域和区域经理分析销售业绩
   - 评估不同区域的表现差异

3. **门店分析**
   - 比较各门店的销售表现
   - 识别高绩效和低绩效门店

4. **商品分析**
   - 分析不同商品类别的销售情况
   - 评估价格策略（平均单价变化）

5. **KPI 追踪**
   - 通过交通灯指示器快速识别目标达成情况
   - 监控关键业务指标

---

## 🔑 关键特性

1. **星型模型设计** - 优化查询性能和易用性
2. **时间智能** - 支持年度对比分析
3. **场景对比** - 通过 ScenarioID 灵活对比不同时期数据
4. **KPI 可视化** - 交通灯状态指示器直观展示绩效
5. **多维度筛选** - 6个筛选器支持灵活的数据切片
6. **丰富的度量值** - 30+ 个 DAX 度量值覆盖各类业务需求
7. **PBIP 格式** - 使用 Power BI Project 格式，便于版本控制和团队协作

---

## 📝 技术栈

- **平台**: Microsoft Power BI
- **数据库**: SQL Server (RetailBIDW)
- **数据建模语言**: TMDL (Tabular Model Definition Language)
- **数据转换**: Power Query (M语言)
- **计算逻辑**: DAX (Data Analysis Expressions)
- **可视化**: Power BI 原生可视化组件
- **项目格式**: PBIP (Power BI Project)

---

## 📊 数据量级

- **Sales 表采样率**: 10%
- **时间粒度**: 月度
- **数据年份**: 两年对比（今年 vs 去年）
- **关系数量**: 6个主要关系
- **度量值数量**: 30+ 个
- **可视化组件**: 7个

---

**文档生成时间**: 2025-10-18
**分析工具**: Claude Code (Sonnet 4.5)
